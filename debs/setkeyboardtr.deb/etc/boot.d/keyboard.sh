#!/bin/bash
/usr/bin/setxkbmap tr
